Credits:
- Mathieu-André Chiasson (Code)
- Mike Keogh (Audio)
- Pierre Proulx (Audio)
- David St-Louis (Art)
- Sean Sullivan (Code)

Tools:
- Visual Studio Code
- github
- Oak Nut engine (onut)
- Aseprite (Color palette from MortMort)
