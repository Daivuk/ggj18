<?xml version="1.0" encoding="UTF-8"?>
<tileset name="tileset" tilewidth="16" tileheight="16" tilecount="64" columns="8">
 <image source="../textures/tileset.png" width="128" height="128"/>
</tileset>
